from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
from pipeline import (
    ingest_data,
    run_gx_validation_before,
    preprocess_data,
    run_gx_validation_after,
    train_model
)
import mlflow.sklearn
import numpy as np
from mlflow.tracking import MlflowClient

app = FastAPI(title="Student Depression ML Pipeline API")

@app.get("/")
def root():
    return {"message": "Student Depression ML Pipeline API is running."}

@app.post("/ingest")
def trigger_ingest(background_tasks: BackgroundTasks):
    background_tasks.add_task(ingest_data)
    return {"status": "Data ingestion started in background."}

@app.post("/validate/before")
def trigger_validation_before(background_tasks: BackgroundTasks):
    background_tasks.add_task(run_gx_validation_before)
    return {"status": "Data validation (before preprocessing) started in background."}

@app.post("/preprocess")
def trigger_preprocess(background_tasks: BackgroundTasks):
    background_tasks.add_task(preprocess_data)
    return {"status": "Data preprocessing started in background."}

@app.post("/validate/after")
def trigger_validation_after(background_tasks: BackgroundTasks):
    background_tasks.add_task(run_gx_validation_after)
    return {"status": "Data validation (after preprocessing) started in background."}

@app.post("/train")
def trigger_train(background_tasks: BackgroundTasks):
    background_tasks.add_task(train_model)
    return {"status": "Model training started in background."}

# Define your input features here. Add/remove fields as per your model.
class PredictionInput(BaseModel):
    Gender: str
    Age: int
    City: str
    Profession: str
    Academic_Pressure: int
    CGPA: float
    Study_Satisfaction: int
    Sleep_Duration: str
    Dietary_Habits: str
    Degree: str
    Have_you_ever_had_suicidal_thoughts: str
    Work_Study_Hours: int
    Financial_Stress: int
    Family_History_of_Mental_Illness: str

@app.post("/predict")
def predict(input_data: PredictionInput):
    # Example: simple label encoding for demonstration
    # In production, use the same preprocessing as in your training pipeline!
    gender_map = {"Male": 0, "Female": 1, "Other": 2}
    city_map = {"CityA": 0, "CityB": 1, "CityC": 2}  # Replace with your actual mapping
    profession_map = {"Student": 0, "Employed": 1, "Other": 2}  # Replace as needed
    degree_map = {"Bachelors": 0, "Masters": 1, "PhD": 2}  # Replace as needed
    diet_map = {"Veg": 0, "Non-Veg": 1, "Other": 2}  # Replace as needed
    suicidal_map = {"Yes": 1, "No": 0}
    family_history_map = {"Yes": 1, "No": 0}

    # Apply encoding (update mappings as per your training pipeline)
    gender = gender_map.get(input_data.Gender, 0)
    city = city_map.get(input_data.City, 0)
    profession = profession_map.get(input_data.Profession, 0)
    degree = degree_map.get(input_data.Degree, 0)
    diet = diet_map.get(input_data.Dietary_Habits, 0)
    suicidal = suicidal_map.get(input_data.Have_you_ever_had_suicidal_thoughts, 0)
    family_history = family_history_map.get(input_data.Family_History_of_Mental_Illness, 0)

    # Prepare input for prediction (order must match training)
    input_array = np.array([[
        gender,
        input_data.Age,
        city,
        profession,
        input_data.Academic_Pressure,
        input_data.CGPA,
        input_data.Study_Satisfaction,
        degree,
        diet,
        suicidal,
        input_data.Work_Study_Hours,
        input_data.Financial_Stress,
        family_history
    ]])

    # Load the latest model from the latest MLflow run (not Model Registry)
    mlflow.set_tracking_uri("http://localhost:5000")
    client = MlflowClient()
    experiment = client.get_experiment_by_name("student_depression_classification")
    if experiment is None:
        raise RuntimeError("No MLflow experiment found with name 'student_depression_classification'. Train a model first.")
    
    runs = client.search_runs(experiment.experiment_id, order_by=["attributes.start_time DESC"])
    if not runs:
        raise RuntimeError("No runs found in MLflow experiment 'student_depression_classification'. Train a model first.")
    
    latest_run_id = runs[0].info.run_id
    model_uri = f"runs:/{latest_run_id}/model"
    model = mlflow.sklearn.load_model(model_uri)

    # Predict
    prediction = model.predict(input_array)[0]
    return {"prediction": int(prediction)}